# Kullanım Rehberi

- `main.py` ile botu başlatabilirsiniz.
- `config.py` dosyasındaki ayarları düzenleyin.
- Proxy ve site listelerini `data/` klasöründe güncelleyin.
- Yorum şablonlarını `comments.txt` dosyasına ekleyin.
- Raporlar `archive.json` içinde saklanır.

## Destek
Sorularınız için destek talebi açabilirsiniz.