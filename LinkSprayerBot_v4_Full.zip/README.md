# LinkSprayer Bot v4 - Full Paket

## Kurulum
1. Python 3.8+ yüklü olduğundan emin olun.
2. Gerekli kütüphaneleri yükleyin:
   ```
   pip install -r requirements.txt
   ```
3. `config.py` içindeki API anahtarlarını kendi değerlerinizle değiştirin.
4. `data/` klasöründeki örnek proxy, site ve yorum dosyalarını düzenleyin.
5. `main.py` dosyasını çalıştırın:
   ```
   python main.py
   ```

## Özellikler
- AI destekli yorum üretici
- Proxy yönetimi ve IP rotasyonu
- SEO analizleri (Ahrefs, Majestic entegrasyonu)
- Otomatik form gönderimi
- Backlink takip ve raporlama
- Discord, Slack, Telegram entegrasyonları
- Ve çok daha fazlası!

## Kullanım
Detaylı kullanım için `docs/` klasöründeki dökümantasyonları inceleyin.