import random
import re

def generate(text):
    # Spintax çözümleyici (örnek: {Merhaba|Selam})
    def spin(match):
        options = match.group(1).split('|')
        return random.choice(options)

    pattern = re.compile(r'\{([^{}]+)\}')
    while re.search(pattern, text):
        text = pattern.sub(spin, text)
    return text