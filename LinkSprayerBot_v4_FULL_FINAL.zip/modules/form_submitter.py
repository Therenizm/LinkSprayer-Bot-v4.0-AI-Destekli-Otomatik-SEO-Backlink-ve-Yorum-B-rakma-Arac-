import requests

def submit_comment(site_url, comment, proxy=None):
    try:
        headers = {
            "User-Agent": "Mozilla/5.0",
        }
        proxies = {
            "http": proxy,
            "https": proxy
        } if proxy else None

        # Basit bir POST örneği (form verisi simülasyon)
        payload = {
            "comment": comment,
            "name": "LinkSprayerBot",
            "email": "bot@example.com"
        }

        response = requests.post(site_url, data=payload, headers=headers, proxies=proxies, timeout=10)

        if response.status_code in [200, 201]:
            return True
        return False
    except Exception as e:
        print(f"Submit Error: {e}")
        return False