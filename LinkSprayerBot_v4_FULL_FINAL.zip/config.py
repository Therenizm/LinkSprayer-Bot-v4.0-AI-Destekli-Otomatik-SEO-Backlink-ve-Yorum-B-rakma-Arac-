# API ve Genel Ayarlar

AHREFS_API_KEY = "your-ahrefs-api-key"
MAJESTIC_API_KEY = "your-majestic-api-key"
DISCORD_WEBHOOK = "your-discord-webhook-url"
SLACK_WEBHOOK = "your-slack-webhook-url"

PROXY_FILE = "data/proxies.txt"
SITES_FILE = "data/sites.txt"
COMMENTS_FILE = "data/comments.txt"
ARCHIVE_FILE = "data/archive.json"

# Diğer ayarlar...