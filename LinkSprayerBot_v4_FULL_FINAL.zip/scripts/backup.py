# Yedekleme Scripti

import shutil
import datetime

def backup_data():
    now = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    shutil.make_archive(f"backup_{now}", 'zip', 'data')

if __name__ == "__main__":
    backup_data()