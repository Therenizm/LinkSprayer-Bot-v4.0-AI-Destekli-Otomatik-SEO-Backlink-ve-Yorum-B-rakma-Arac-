import time
import random
import requests
from modules import ai_comment_generator, proxy_manager, form_submitter
from config import SITES_FILE, PROXY_FILE, COMMENTS_FILE

def load_sites():
    with open(SITES_FILE, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def load_proxies():
    with open(PROXY_FILE, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def load_comments():
    with open(COMMENTS_FILE, "r", encoding="utf-8") as f:
        return [line.strip() for line in f if line.strip()]

def main():
    print("🔁 LinkSprayer Bot v4.0 Başlatıldı...")
    sites = load_sites()
    proxies = load_proxies()
    comments = load_comments()

    for site in sites:
        proxy = random.choice(proxies) if proxies else None
        comment = ai_comment_generator.generate(random.choice(comments))
        print(f"🌐 Site: {site}")
        print(f"✍️  Yorum: {comment}")
        print(f"🔐 Proxy: {proxy or 'Yok'}")

        try:
            result = form_submitter.submit_comment(site, comment, proxy)
            if result:
                print(f"✅ Yorum gönderildi: {site}\n")
            else:
                print(f"❌ Yorum başarısız: {site}\n")
        except Exception as e:
            print(f"⚠️  Hata ({site}): {e}\n")

        time.sleep(random.randint(3, 6))  # doğal görünmek için bekle

if __name__ == "__main__":
    main()